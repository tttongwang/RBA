# -*- coding: utf-8 -*-
"""
Created on Tue Apr 26 14:08:15 2022

@author: tongw
"""
linucb_alpha = 1.25


sample_size  = 500
B            = 2000
feature_d    = 2


# try smaller Repeats to double check code
Repeats      = 10

#K: #of arms
K            = 2 