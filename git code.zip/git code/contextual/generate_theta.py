# -*- coding: utf-8 -*-
"""

@author: tongw


"""
import numpy as np
from generate_common_paras import K

theta    = dict.fromkeys(range(K))
theta[0] = np.array([1.8,2.2])
theta[1] = np.array([2,2])