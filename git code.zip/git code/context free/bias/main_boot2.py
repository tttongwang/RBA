from boot_experiments2 import Experiments
import numpy as np
from settings import dist,sys_sep, true_prob,sigma,sample_size,repeats,gap,algo_list,random_choice,boot_number,infer_bool

x = np.arange(-3, 3 + 0.25, 0.25)

plot_total_bool = True
plot_bool = False

lin = False
#lin_t=T means: linear
#lin_t=F means: linear_const
lin_t = False
lin_const = len(true_prob)


dp = False 
dp_eps = 150


gd_eps = 0.1
lil_delta = 0.005
lil_beta = 1
lil_eps = 0.01
lil_lambda = 9
#rc_list = ["water_filling","uniform"]
#print(infer_bool)

for algo in algo_list:
    experiments = Experiments(x = x, infer_bool=infer_bool, plot_total_bool=plot_total_bool, plot_bool=plot_bool,
     boot_number=boot_number, dist = dist, sys_sep=sys_sep, algo=algo,
                lin=lin, lin_t=lin_t, lin_const=lin_const, random_choice=random_choice,
                true_prob=true_prob, sample_size=sample_size, repeats=repeats, gap=gap, 
                gd_eps=gd_eps, sigma=sigma, lil_delta=lil_delta, lil_eps=lil_eps, 
                lil_lambda=lil_lambda, lil_beta=lil_beta, dp=dp, dp_eps=dp_eps)
    experiments.set_path()
    experiments.total_outputs()




