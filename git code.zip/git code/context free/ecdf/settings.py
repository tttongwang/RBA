######parameter settings for the family of main functions
import pandas as pd
from sys import platform

if platform == "linux" or platform == "linux2":
	sys_sep = "/"
	# linux
elif platform == "darwin":
	sys_sep = "/"
	# OS X
elif platform == "win32":
	sys_sep = "\\"
#sys_sep = "\\"


sample_size = 100
boot_number = 2000
repeats = 200

dist = "norm"
#random_choice = "water_filling"
random_choice = "uniform"

#true_prob = [0,0.9,1]

true_prob = [2,1.5,1,0.75,0.5]
#true_prob = [2,1]


scale_number = 0.5
s = pd.Series(true_prob)
true_prob = (s * scale_number).tolist()
sigma = 1

if len(true_prob)==2:
	infer_bool = True 
else:
	infer_bool = False



gap = 10

algo_list = ["greedy","lil_ucb","ts","t_greedy"]
#algo_list = ["ts","lil_ucb","t_greedy"]
#algo_list = ["greedy","t_greedy"]

#algo_list=['ts',"lil_ucb"]
#algo_list = ["lil_ucb"]
#algo_list = ["ts"]
